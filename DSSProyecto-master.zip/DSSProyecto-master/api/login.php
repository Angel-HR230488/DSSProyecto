<?php
header('Content-Type: application/json');

include '../config/database.php';
include '../modules/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['username']) && isset($data['password'])) {
        $username = $data['username'];
        $password = $data['password'];

        if (login($username, $password, $conn)) {
            echo json_encode(['status' => 'success', 'message' => '¡Inicio de sesión exitoso!']);
        } else {
            http_response_code(401);
            echo json_encode(['status' => 'error', 'message' => 'Nombre de usuario o contraseña incorrectos.']);
        }
    } else {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Datos incompletos.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.']);
}
?>