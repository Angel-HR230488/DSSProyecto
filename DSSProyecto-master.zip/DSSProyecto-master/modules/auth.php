<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Iniciar sesión si aún no está iniciada
}

include __DIR__ . '/../config/database.php';

// Función para iniciar sesión
function login($username, $password, $conn) {
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Usuario autenticado
            $_SESSION['username'] = $username;
            return true;
        }
    }
    // Fallo de autenticación
    return false;
}

// Función para registrar un nuevo usuario
function register($username, $password, $email, $conn) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $hashed_password, $email);
    return $stmt->execute();
}

// Función para cerrar sesión
function logout() {
    session_start();
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>