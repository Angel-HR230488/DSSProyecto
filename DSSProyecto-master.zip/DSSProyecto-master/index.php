<?php
include __DIR__ . '/config/database.php';
include __DIR__ . '/modules/auth.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Iniciar sesión si aún no está iniciada
}

$success = ""; // Variable para mensajes de éxito

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (login($username, $password, $conn)) {
        $success = "¡Inicio de sesión exitoso!";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="public/css/style.css">
    <script>
        async function loginUser(event) {
            event.preventDefault();
            const form = event.target;
            const formData = new FormData(form);
            const data = {
                username: formData.get('username'),
                password: formData.get('password')
            };

            try {
                const response = await fetch('api/login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });

                const result = await response.json();
                const messageElement = document.getElementById('message');
                if (response.ok) {
                    messageElement.style.color = 'green';
                    messageElement.textContent = result.message;
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    messageElement.style.color = 'red';
                    messageElement.textContent = result.message;
                }
            } catch (error) {
                console.error('Error:', error);
                const messageElement = document.getElementById('message');
                messageElement.style.color = 'red';
                messageElement.textContent = 'Error al iniciar sesión.';
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <?php if (!isset($_SESSION['username'])): ?>
            <h2>Iniciar Sesión</h2>
            
            <!-- Mostrar mensaje de error dentro del contenedor -->
            <p id="message" style="text-align: center;"></p>

            <form onsubmit="loginUser(event)">
                <label for="username">Nombre de Usuario:</label>
                <input type="text" id="username" name="username" required>
                <br>
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
                <br>
                <input type="submit" name="login" value="Iniciar Sesión">
            </form>
        <?php else: ?>
            <h2>Bienvenido, <?php echo $_SESSION['username']; ?></h2>
            
            <!-- Mostrar mensaje de éxito dentro del contenedor -->
            <?php if ($success): ?>
                <p id="message" style="color: green; text-align: center;"><?php echo $success; ?></p>
            <?php endif; ?>

            <p><a href="register.php">Registrar Nuevo Usuario</a></p>
            <p><a href="logout.php">Cerrar Sesión</a></p>
        <?php endif; ?>
    </div>
</body>
</html>